package Trial;

public class Wolf extends AnimalNotJump {
    Wolf(Player player) {
        name = "Wolf";
        rank = 4;
        owner = player;
        owner.pieceCount ++;
    }
}
