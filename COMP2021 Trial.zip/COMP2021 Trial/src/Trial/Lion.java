package Trial;

public class Lion extends AnimalJump {
    Lion(Player player) {
        name = "Lion";
        rank = 7;
        owner = player;
        owner.pieceCount ++;
    }
}
