package Trial;

public class Cat extends AnimalNotJump {
    Cat(Player player) {
        name = "Cat";
        rank = 2;
        owner = player;
        owner.pieceCount ++;
    }
}
