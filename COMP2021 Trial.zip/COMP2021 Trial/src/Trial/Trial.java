package Trial;

import java.util.*;

public class Trial {
    public static void main (String[] args) {
        Player playerX = new Player ("Tom");
        Player playerY = new Player ("Jerry");
        Board board = new Board (playerX, playerY);
        Scanner scanner = new Scanner (System.in);
        String command = null;
        String[] commandArray = null;
        boolean valid = false;
        while (!board.victory) {
            while (!valid) {
                System.out.println(playerX.name + "'s turn");
                command = scanner.nextLine();
                commandArray = command.split(",");
                if (commandArray[0].equals("move")) {
                    valid = board.step(playerX, Position.valueOf(commandArray[1]), Position.valueOf(commandArray[2]));
                }
                else {
                    System.out.println(playerX.name + " other command");
                    break;
                }
            }
            if (!commandArray[0].equals("move")) {
                break;
            }
            valid = false;
            while (!valid) {
                System.out.println(playerY.name + "'s turn");
                command = scanner.nextLine();
                commandArray = command.split(",");
                if (commandArray[0].equals("move")) {
                    valid = board.step(playerY, Position.valueOf(commandArray[1]), Position.valueOf(commandArray[2]));
                }
                else {
                    System.out.println(playerY.name + " other command");
                    break;
                }
            }
            if (!commandArray[0].equals("move")) {
                break;
            }
        }
        scanner.close();
    }
}