package Trial;

public class Elephant extends AnimalNotJump {
    Elephant(Player player) {
        name = "Elephant";
        rank = 8;
        owner = player;
        owner.pieceCount ++;
    }
}
