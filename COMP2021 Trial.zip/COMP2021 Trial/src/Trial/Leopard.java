package Trial;

public class Leopard extends AnimalNotJump {
    Leopard(Player player) {
        name = "Leopard";
        rank = 5;
        owner = player;
        owner.pieceCount ++;
    }
}
